# Caso “Pet Shop (Fullstack Python)”


Creado por Cristóbal Villarroel Briceño para certificación Talento Digital y Edutecno.



Paso para ejecutar el proyecto:
-------------------------------


1) Crear un ambiente virtual, activarla e instalar las dependencias usando:

    >    pip install -r requirements.txt


2) Crear una base de datos en Postgres llamada: 
    > patitas_petshop

3) Cambiarse a la carpeta patitas_petshop


4) Ejecutar las migraciones:

    > python3 manage.py makemigrations
    >
    > python3 manage.py migrate



5) Ejecutar el proyecto:

    > python manage.py runserver



Datos de usuarios:
------------------

a) Super Usuario (Margarita):


> usuario:       admin
>
> contraseña:    1234 


b) Usuarios:  

> usuario:        cvillarroel@mail.com
>
> contraseña:     certificacion


> usuario:        pperez@patitaspetshop.com
>
> contraseña:     certificacion
