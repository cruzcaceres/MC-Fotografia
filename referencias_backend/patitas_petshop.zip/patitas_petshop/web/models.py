from django.db import models
from django.contrib.auth.models import User

class Categoria(models.Model):
    id = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=255)
    
    def __str__(self):
        return f'{self.nombre}'
    
class Producto(models.Model):
    id = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=50)
    categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE)
    precio = models.IntegerField(null=True, blank=True)
    descripcion = models.TextField(null=True, blank=True)
    cantidad = models.IntegerField(blank=True, null=True)
    imagen = models.URLField(blank=True, null=True)
    destacado = models.BooleanField(default=False)

    def __str__(self):
        return f'Nombre: {self.nombre}'

class PreOrden(models.Model):
    id = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    fecha = models.DateField()
    cantidad = models.IntegerField()

    def __str__(self):
        return f'{self.producto.nombre}'
    
class Servicio(models.Model):
    id = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=100)
    precio = models.IntegerField(null=True, blank=True)
    duracion = models.CharField(max_length=50)
    imagen = models.URLField(blank=True, null=True)
    descripcion = models.TextField(null=True, blank=True)

    def __str__(self):
        return f'Nombre: {self.nombre}'