from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.views import View
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
from datetime import timedelta, date
from django.urls import reverse, reverse_lazy
from django.contrib.auth import authenticate, login
from django.contrib.messages.views import SuccessMessageMixin
from django.contrib.auth.views import LoginView, LogoutView
from .forms import CategoriaFilterForm
from .models import *

class RegisterView(View):
    def get(self, request):
        return render(request, 'registration/register.html')

    def post(self, request):
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')
        if password1 != password2:
            messages.error(request, 'Passwords do not match')
            return redirect(reverse('register'))  
        user = User.objects.create_user(username=email, email=email, password=password1, first_name=first_name, last_name=last_name)
        user.save()
        user = authenticate(username=email, password=password1)
        if user is not None:
            login(request, user)
        messages.success(request, 'Usuario creado exitosamente')
        return redirect('index')
    
class CustomLoginView(SuccessMessageMixin, LoginView):
    success_message = "Sesion Iniciada Exitosamente"
    template_name = 'registration/login.html'  
    redirect_authenticated_user = True
    
class CustomLogoutView(LogoutView):
    next_page = reverse_lazy('login')
    def dispatch(self, request, *args, **kwargs):
        response = super().dispatch(request, *args, **kwargs)
        messages.add_message(request, messages.WARNING, "Sesion Cerrada Exitosamente")
        return response
        

def index(request):
    productos = Producto.objects.filter(destacado=True)
    return render(request, 'index.html', {'productos': productos})

@login_required
def catalogo(request):
    form = CategoriaFilterForm(request.GET)  
    
    if form.is_valid():
        categoria = form.cleaned_data.get('categoria')  
        if categoria:
            productos = Producto.objects.filter(categoria=categoria)  
        else:
            productos = Producto.objects.all() 
    else:
        productos = Producto.objects.all()

    return render(request, 'catalogo.html', {'productos': productos, 'form': form})

@login_required
def servicios(request):
    servicios = Servicio.objects.all()
    return render(request, 'servicios.html', {'servicios': servicios})

@login_required
def detalle_producto(request, producto_id):
    producto = get_object_or_404(Producto, id=producto_id)
    return render(request, 'detalle_producto.html', {'producto': producto})

@login_required
def detalle_servicio(request, servicio_id):
    servicio = get_object_or_404(Servicio, id=servicio_id)
    return render(request, 'detalle_servicio.html', {'servicio': servicio})

@login_required
def crear_preorden(request, producto_id):
    producto = get_object_or_404(Producto, id=producto_id)
    
    PreOrden.objects.create(
        user=request.user,
        producto=producto,
        fecha=date.today(),
        cantidad=1  
    )
    
    messages.success(request, 'Hemos recibido tu pre-orden. Te contactaremos cuando esté disponible el producto.')
    return redirect('index')