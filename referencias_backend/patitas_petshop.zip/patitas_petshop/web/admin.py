from django.contrib import admin
from .models import *

admin.site.register(Categoria)
admin.site.register(Producto)
admin.site.register(PreOrden)
admin.site.register(Servicio)