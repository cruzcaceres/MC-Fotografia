from django.urls import path
from web.views import *

urlpatterns = [
    path('', index, name='index'),
    path('accounts/login/', CustomLoginView.as_view(), name='login'),
    path('accounts/logout/', CustomLogoutView.as_view(), name='logout'),
    path('accounts/register/', RegisterView.as_view(), name='register'),
    path('catalogo/', catalogo, name='catalogo'),
    path('servicios/', servicios, name='servicios'),
    path('producto/<int:producto_id>/detalle_producto/', detalle_producto, name='detalle_producto'),
    path('servicios/<int:servicio_id>/detalle_servicio/', detalle_servicio, name='detalle_servicio'),
    path('producto/<int:producto_id>/preorden/', crear_preorden, name='crear_preorden'),
]